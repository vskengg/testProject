package com.cisco.wem.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CookieStore;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

public class WebServiceClient {

	/**
	 * This method generates the OAM token by passing the credentials.
	 * 
	 * @return
	 */
	public String generateOAMToken() {
		String ssoToken = null;
		try {
			HttpHost targetHost = new HttpHost("fdk-author-stage.cisco.com", 443, "https");
			DefaultHttpClient client = new DefaultHttpClient();
			BufferedReader rd = null;
			try {
				SSLSocketFactory socketFactory = new SSLSocketFactory(createEasySSLContext());
				Scheme sch = new Scheme("https", 443, socketFactory);
				client.getConnectionManager().getSchemeRegistry().register(sch);

				HttpPost post = new HttpPost("https://fdk-author-stage.cisco.com/c/login/index.html");

				AuthScope authScope = new AuthScope(targetHost.getHostName(), targetHost.getPort());
				UsernamePasswordCredentials creds = new UsernamePasswordCredentials("cgcoreapp.gen", "cgcoreapp@wem");
				client.getCredentialsProvider().setCredentials(authScope, creds);

				// Create AuthCache instance
				AuthCache authCache = new BasicAuthCache();
				// Generate BASIC scheme object and add it to the local
				// auth cache
				BasicScheme basicAuth = new BasicScheme();
				authCache.put(targetHost, basicAuth);

				// Add AuthCache to the execution context
				BasicHttpContext localcontext = new BasicHttpContext();
				localcontext.setAttribute(ClientContext.AUTH_CACHE, authCache);

				HttpResponse response = client.execute(targetHost, post, localcontext);
				System.out.println(response.getStatusLine());
				rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line = "";
				while ((line = rd.readLine()) != null) {
					System.out.println(line);
				}
				org.apache.http.Header[] allHeaders = response.getAllHeaders();
				for (int i = 0; i < allHeaders.length; i++) {
					System.out.println("Header Name:" + allHeaders[i].getName());
					System.out.println("Header Value:" + allHeaders[i].getValue());
				}
				List<org.apache.http.cookie.Cookie> cookies = client.getCookieStore().getCookies();
				if (cookies.isEmpty()) {
					System.out.println("None");
				} else {
					for (int i = 0; i < cookies.size(); i++) {
						System.out.println("- " + cookies.get(i).toString());
						String cookie = cookies.get(i).getName();
						if ("ObSSOCookie".equalsIgnoreCase(cookie)) {
							ssoToken = cookies.get(i).getValue();
						}
					}
				}
			} finally {
				if (rd != null) {
					rd.close();
				}
				client.getConnectionManager().shutdown();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("SSOToken = " + ssoToken);
		return ssoToken;
	}

	/**
	 * This method calls the activatecontent webservice using the generated OAM
	 * token.
	 * 
	 * @param path
	 * @return
	 * @throws JSONException
	 */
	public String activateContent(String path) throws JSONException {
		try {
			HttpHost targetHost = new HttpHost("fdk-author-stage.cisco.com", 443, "https");
			DefaultHttpClient client = new DefaultHttpClient();
			BufferedReader rd = null;
			try {
				SSLSocketFactory socketFactory = new SSLSocketFactory(createEasySSLContext());
				Scheme sch = new Scheme("https", 443, socketFactory);
				client.getConnectionManager().getSchemeRegistry().register(sch);

				String ssoToken = generateOAMToken();
				HttpPost post = new HttpPost(
						"/c/wcm/servlets/services/wem.activatecontent.json");

				CookieStore cookieStore = new BasicCookieStore();
				BasicClientCookie cookie = new BasicClientCookie("ObSSOCookie", ssoToken);
				cookie.setDomain(".cisco.com");
				cookie.setPath("/");
				cookieStore.addCookie(cookie);
				client.setCookieStore(cookieStore);

				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("path", path));
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = client.execute(targetHost, post);
				System.out.println(response.getStatusLine());
				rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

				StringBuffer content = new StringBuffer();
				String line = "";
				while ((line = rd.readLine()) != null) {
					content.append(line);
				}
				System.out.println(content.toString());
				JSONObject jsonObject = new JSONObject(content.toString());
				String statusCode = jsonObject.getString("statuscode");
				String statusMessage = jsonObject.getString("statusmessage");
				String sourcePath = jsonObject.has("sourcepath") ? jsonObject.getString("sourcepath") : "";
				System.out.println("statusCode" + statusCode);
				System.out.println("statusMessage" + statusMessage);
				System.out.println("sourcePath" + sourcePath);
			} finally {
				if (rd != null) {
					rd.close();
				}
				client.getConnectionManager().shutdown();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "Success";
	}

	/**
	 * This method calls the uploadcontent webservice.
	 * 
	 * @param filePath the file to be
	 * @return
	 * @throws JSONException
	 */
	public String uploadcontent(String filePath, String contentMetadata, String mimeType) throws JSONException {
		try {
			HttpHost targetHost = new HttpHost("fdk-author-stage.cisco.com", 443, "https");
			//HttpHost targetHost = new HttpHost("localhost", 4506, "http");
			DefaultHttpClient client = new DefaultHttpClient();
			BufferedReader rd = null;
			try {
				SSLSocketFactory socketFactory = new SSLSocketFactory(createEasySSLContext());
				Scheme sch = new Scheme("https", 443, socketFactory);
				client.getConnectionManager().getSchemeRegistry().register(sch);

				String ssoToken = generateOAMToken();
				HttpPost post = new HttpPost("/c/wcm/servlets/services/wem.uploadcontent.json");
				
				//post.addHeader("AUTH_USER", "admin");

				CookieStore cookieStore = new BasicCookieStore();
				BasicClientCookie cookie = new BasicClientCookie("ObSSOCookie", ssoToken);
				cookie.setDomain(".cisco.com");
				cookie.setPath("/");
				cookieStore.addCookie(cookie);
				client.setCookieStore(cookieStore);

				FileBody content = new FileBody(new File(
						filePath), mimeType);
				StringBody metadata = new StringBody(contentMetadata, "text/plain", Charset.forName("UTF-8"));

				MultipartEntity reqEntity = new MultipartEntity();
				reqEntity.addPart("content", content);
				reqEntity.addPart("metadata", metadata);

				post.setEntity(reqEntity);
				
				HttpResponse response = client.execute(targetHost, post);
				System.out.println(response.getStatusLine());
				rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

				StringBuffer responseContent = new StringBuffer();
				String line = "";
				while ((line = rd.readLine()) != null) {
					responseContent.append(line);
				}
				System.out.println(responseContent.toString());
				JSONObject jsonObject = new JSONObject(responseContent.toString());
				String statusCode = jsonObject.getString("statuscode");
				String statusMessage = jsonObject.getString("statusmessage");
				String sourcePath = jsonObject.has("sourcepath") ? jsonObject.getString("sourcepath") : "";
				System.out.println("statusCode" + statusCode);
				System.out.println("statusMessage" + statusMessage);
				System.out.println("sourcePath" + sourcePath);
			} finally {
				if (rd != null) {
					rd.close();
				}
				client.getConnectionManager().shutdown();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "Success";
	}

	private static SSLContext createEasySSLContext() {
		SSLContext context = null;
		try {
			context = SSLContext.getInstance("SSL");
			context.init(null, new TrustManager[] { new FakeX509TrustManager() }, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return context;
	}

	public static void main(String[] args) throws JSONException {
		WebServiceClient client = new WebServiceClient();
		String filePath = "C:/temp/XMART files/secondimport/secondimportbook/fourthimport.html";
		//String filePath = "C:/temp/XMART files/secondimport/secondimportbook/fourthimport.pdf";
		
		//DEV
		//String metadata = "{'path':'/content/dam/en/us/td/docs/dev/fourthimport', 'rendition':'no', 'attributes': {'cisco:assetType':'Book', 'cisco:concept':['Products:Cisco Products/Routers/Branch Routers/Cisco 7000 Series Routers/Cisco 7000 Router', 'Products:Cisco Products/Routers/Branch Routers/Cisco 7000 Series Routers/Cisco 7010 Router'], 'cisco:docType':'DocTypes:HOME/SUPPORT/TSD Products Support Home/TSD Products Support Category Home/TSD Products Support Series Home/TSD Products Support Configure/TSD Products Support Configuration Guides List/TSD Products Configuration Guide Book', 'dc:title':'fourthimport', 'dc:description':'Book Description'}, 'relations': [{'name':'setup', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/setup.html', 'type':'chapter'}, {'name':'overview', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/overview.html', 'type':'chapter'}, {'name':'Part1', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/install.html', 'type':'part', 'relations':[{'name':'install', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/install.html', 'type':'chapter'}, {'name':'about', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/about.html', 'type':'chapter'} ]}, {'name':'uninstall', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/uninstall.html', 'type':'chapter', 'relations': [{'name':'151003', 'path':'/content/dam/en/us/td/i/000001-100000/151003.tif', 'type':'reference'}, {'name':'151004', 'path':'/content/dam/en/us/td/i/000001-100000/151004.tif', 'type':'reference'} ]} ] }";
		
		//stage
		String metadata = "{'path':'/content/dam/en/us/td/docs/dev/fourthimport', 'rendition':'no', 'attributes': {'cisco:assetType':'Book', 'cisco:concept':['Products:Cisco Products/Routers/Branch Routers/Cisco 7000 Series Routers/Cisco 7000 Router', 'Products:Cisco Products/Routers/Branch Routers/Cisco 7000 Series Routers/Cisco 7010 Router'], 'cisco:docType':'DocTypes:HOME/SUPPORT/TSD Products Support Home/TSD Products Support Category Home/TSD Products Support Series Home/TSD Products Support Configure/TSD Products Support Configuration Guides List/TSD Products Configuration Guide Book', 'dc:title':'fourthimport', 'dc:description':'Book Description'}, 'relations': [{'name':'setup', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/setup.html', 'type':'chapter'}, {'name':'overview', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/overview.html', 'type':'chapter'}, {'name':'Part1', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/install.html', 'type':'part', 'relations':[{'name':'install', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/install.html', 'type':'chapter'}, {'name':'about', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/about.html', 'type':'chapter'} ]}, {'name':'uninstall', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/uninstall.html', 'type':'chapter', 'relations': [{'name':'10003', 'path':'/content/dam/en/us/td/i/000001-100000/10001-15000/10001-10500/10003.ps', 'type':'reference'}, {'name':'10005', 'path':'/content/dam/en/us/td/i/000001-100000/10001-15000/10001-10500/10005.ps', 'type':'reference'} ]} ] }";
		

		//String metadata = "{ 'path':'/content/dam/en/us/td/docs/dev/fourthimport/fourthimport.html', 'rendition':'yes' }";
		//local
		//String metadata = "{'path':'/content/dam/en/us/td/docs/dev/fourthimport', 'rendition':'no', 'attributes': {'cisco:assetType':'Book', 'cisco:concept':['marketing:interest'], 'cisco:docType':'marketing:interest/business', 'dc:title':'fourthimport', 'dc:description':'Book Description'}, 'relations': [{'name':'setup', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/setup.html', 'type':'chapter'}, {'name':'overview', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/overview.html', 'type':'chapter'}, {'name':'Part1', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/install.html', 'type':'part', 'relations':[{'name':'install', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/install.html', 'type':'chapter'}, {'name':'about', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/about.html', 'type':'chapter'} ]}, {'name':'uninstall', 'path':'/content/dam/en/us/td/docs/dev/fourthimport/uninstall.html', 'type':'chapter', 'relations': [{'name':'nodrm', 'path':'/content/dam/geometrixx/drm/no-drm.jpg', 'type':'reference'}, {'name':'withdrm', 'path':'/content/dam/geometrixx/drm/with-drm.jpg', 'type':'reference'} ]} ] }";
		client.uploadcontent(filePath, metadata, "text/html");
	}

}
