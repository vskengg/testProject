package com.cisco.wem.client;

import java.net.*;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.*;

import org.apache.commons.codec.binary.Base64;

public class NBC
{
	public static void main(String args[]) throws Exception
	{
		int i = -1;
		
		String urlstr = "http://fdk-author-dev3.cisco.com/c/login/index.html"; 
		String userid = "XXXX";
		String password = "XXXXX";
		
		URL url = new URL(urlstr);
		HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
		urlConn.setRequestMethod("POST");	
		
		// For authenticating with Authorization header.
		String authString = userid + ":" + password;
		String auth = "Basic " + new String(Base64.encodeBase64(authString.getBytes()));
		urlConn.setRequestProperty("Authorization", auth);
		
		urlConn.connect();
		Map<String, List<String>> headerFields = urlConn.getHeaderFields();
		Iterator<String> iterator = headerFields.keySet().iterator();
		while (iterator.hasNext()) {
			String key = (String) iterator.next();
			List<String> list = headerFields.get(key);
			System.out.println("key + " + key);
			System.out.println("value: + " + list);
			
		}
		System.out.println("Got code - "+urlConn.getResponseCode());
		BufferedReader in = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
		while ((i = in.read()) != -1)
			System.out.print((char) i);				
		
		InputStream is = urlConn.getInputStream();
		BufferedReader input = new BufferedReader(new InputStreamReader(is));
		
		String line = null;
		while ((line = input.readLine()) != null) {
			System.out.println(line);
		}        
        urlConn.disconnect();
	}
} 
